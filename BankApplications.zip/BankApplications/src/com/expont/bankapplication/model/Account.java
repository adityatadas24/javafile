package com.expont.bankapplication.model;

public class Account {

	private int accNo;
	private String accName;
	private String adharcard;
	private String pancard;
	private long contact;
	private String email;
	private double accBalance;

	public int getAccNo() {
		return accNo;
		
		
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	public String getAccName() {
		return accName;
	}

	public void setAccName(String accName) {
		this.accName = accName;
	}

	public String getAdharcard() {
		return adharcard;
	}

	public void setAdharcard(String adharcard) {
		this.adharcard = adharcard;
	}

	public String getPancard() {
		return pancard;
	}

	public void setPancard(String pancard) {
		this.pancard = pancard;
	}

	public long getContact() {
		return contact;
	}

	public void setContact(long contact) {
		this.contact = contact;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public double getAccBalance() {
		return accBalance;
	}

	public void setAccBalance(double accBalance) {
		this.accBalance = accBalance;
	}

	@Override
	public String toString() {
		return " accNo = " + accNo + ", accName = " + accName + ", adharcard = " + adharcard + ", pancard = " + pancard
				+", \n"+ " contact = " + contact + ", email = " + email + ", accBalance = " + accBalance + "/n";
	}
	
	

}
