package com.exponent.bankapplication.controller;

import java.util.Scanner;

import com.exponent.bankapplication.service.RBI;
import com.exponent.bankapplication.serviceImp.SBI;
import com.exponent.bankapplication.validations.Validation;

public class AdminController {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		RBI rbi = new SBI();

		Validation.passwords(); 

		System.out.println("******* WELCOME TO SBI BANK *******");

		boolean flag = true;

		while (flag) {
			System.out.println();
			System.out.println();
			System.out.println("--------------------------------------------");
			System.out.println("********************************************");
			System.out.println("1: CREATE BANK ACCOUNT                     |");
			System.out.println("2: SHOW ACCOUNT DETAILS                    |");
			System.out.println("3: SHOW All ACCOUNT DETAILS                |");
			System.out.println("4: SHOW ACCOUNT BALANCE                    |");
			System.out.println("5: DEPOSIT MONEY                           |");
			System.out.println("6: WITHDRAWAL MONEY                        |");
			System.out.println("7: UPDATE ACCOUNT DETAILS                  |");
			System.out.println("8: EXIT                                    |");
			System.out.println("********************************************");
			System.out.println("--------------------------------------------");
			System.out.println();

			System.out.println("Enter Your Choice Between 1 to 7");

			int ch = getChoise();
			switch (ch) {
			case 1:
				rbi.createAccount();
				break;
			case 2:
				rbi.showAccountDetails();
				break;
			case 3:
				rbi.showAllAccountDetails();
				break;
			case 4:
				rbi.showAccountBalance();
				break;

			case 5:
				rbi.depositMoney();

				break;
			case 6:
				rbi.withdrawMoney();
				break;
			case 7:
				rbi.updateAccountDetails();
				break;
			case 8:
				flag = false;
				break;
			default:
				System.out.println("invalid details please enter value between 1 to 7");
			}

		}
	}

	public static int getChoise() {
		Scanner sc = new Scanner(System.in);
		int ch;

		try {

			ch = sc.nextInt();

		} catch (Exception e) {
			System.out.println("Invalid Input it must be in number format");
			return getChoise();
		}
		return ch;

	}

}
