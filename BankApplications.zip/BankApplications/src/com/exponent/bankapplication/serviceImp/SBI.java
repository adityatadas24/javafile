package com.exponent.bankapplication.serviceImp;

import java.util.Scanner;

import com.exponent.bankapplication.service.RBI;
import com.exponent.bankapplication.validations.Validation;
import com.expont.bankapplication.model.Account;

public class SBI implements RBI {

	Scanner sc = new Scanner(System.in);
	Account ac = new Account();
	Account a[] = new Account[5];

	@Override
	public void createAccount() {
		System.out.println("Enter how many account you want to create :- ");
		int n = Validation.createsAccountsNo();

		for (int i = 0; i < n; i++) {
			Account ac = new Account();

			System.out.println("Enter Your Account Number :");
			int accNo = Validation.createsAccountsNo();
			ac.setAccNo(accNo);
			System.out.println("Enter Your Name : ");
			ac.setAccName(Validation.holderName());
//				System.out.println("Enter AdharCard Number : ");
			ac.setAdharcard(Validation.adharCardNo());
//				System.out.println("Enter Your PanCard");
			ac.setPancard(Validation.pancard());
//				System.out.println("Enter Your Email Id");
			ac.setEmail(Validation.emailId());
//				System.out.println("Enter Your Contact No. :");
			ac.setContact(Validation.contactNo());
//			System.out.println("Enter Account Opening Balance : ");
			ac.setAccBalance(Validation.accBalance());
			System.out.println();

			System.out.println(1 + i + "st " + "Account Creation Successfully");
			System.out.println();

			a[i] = ac;

		}

	}

	@Override
	public void showAccountDetails() {
		System.out.println("Enter Your Account Number :");

		int accNo = Validation.createsAccountsNo();

		boolean flag = false;

		for (Account acc : a) {
			if (acc != null && acc.getAccNo() == accNo) {
				System.out.println("current Account Balance :" + acc);
				flag = true;
			}

		}

		if (!flag) {
			System.out.println("Account Does't Exist");
		}

	}

	@Override
	public void showAllAccountDetails() {
//		System.out.println("Enter Your Account Number :");
//
//		int accNo = sc.nextInt();

//		if (ac.getAccNo() == accNo) {
//			System.out.println("Account Details : " + ac);
//		} else {
//			System.out.println("Account Does't Exist");
//		}

		for (Account acc : a) {
			if (acc != null) {
				System.out.println("Account Details : " + acc);
			}
		}

	}

	@Override
	public void showAccountBalance() {
		System.out.println("Enter Your Account Number :");

		int accNo = Validation.createsAccountsNo();

		boolean flag = false;

		for (Account acc : a) {
			if (acc != null && acc.getAccNo() == accNo) {
				System.out.println("current Account Balance :" + acc.getAccBalance());
				flag = true;
			}

		}

		if (!flag) {
			System.out.println("Account Does't Exist");
		}

	}

	@Override
	public void depositMoney() {

		System.out.println("Enter your Account No. :");

		int accNo = Validation.createsAccountsNo();

		boolean flag = false;

		for (Account acc : a) {

			if (acc != null && acc.getAccNo() == accNo) {
				System.out.println("Enter Your Deposit Money : ");
				double deposit = sc.nextDouble();
				if (deposit > 0) {

					double updateDeposit = acc.getAccBalance() + deposit;

					acc.setAccBalance(updateDeposit);
					System.out.println("You Successfully Added -> " + deposit + " And Your Account Balance Is :- "
							+ updateDeposit);
					flag = true;
				} else {
					System.out.println("input should be greater than 0");
				}

			}

		}

		if (!flag) {
			System.out.println("Account Does't Exist");
		}

	}

	@Override
	public void withdrawMoney() {
		System.out.println("Enter your Account No. :");
		int accNo = Validation.createsAccountsNo();

		boolean flag = false;

		for (Account acc : a) {

			if (acc != null && acc.getAccNo() == accNo) {

				System.out.println("Enter Your Withdrawal Money : ");
				double withdrawMoney = sc.nextDouble();

				if (withdrawMoney <= acc.getAccBalance()) {

					double updateWithdrawal = acc.getAccBalance() - withdrawMoney;

					acc.setAccBalance(updateWithdrawal);

					System.out.println("You Successfully Withdrawal -> " + withdrawMoney
							+ " And Your Account Balance Is :- " + updateWithdrawal);
				} else {
					System.out.println("Insufficient Account Balance");
				}

				flag = true;

			}
		}

		if (!flag) {
			System.out.println("Account Does't Exist");
		}

	}

	@Override
	public void updateAccountDetails() {
		System.out.println("Enter your Account No. :");
		int accNo = Validation.createsAccountsNo();
		boolean flag = true;
		for (Account acc : a) {

			if (acc != null && acc.getAccNo() == accNo) {

				System.out.println("Here You Can Updates Your Account Details :");
				System.out.println();
				System.out.println("********************************************");
				System.out.println("1: UPDATE YOUR NAME                        |");
				System.out.println("2: UPDATE YOYT CONTACT                     |");
				System.out.println("3: UPDATE YOUR EMAIL                       |");
				System.out.println("4: EXIT                                    |");
				System.out.println("********************************************");
				System.out.println();

				while (flag) {

					int num = sc.nextInt();

					switch (num) {
					case 1:
						updateName();
						break;
					case 2:
						updateContact();
						break;
					case 3:
						updateEmail();
						break;
					case 4:
						flag = false;
						break;
					default:
						System.out.println("invalid enter");

					}

				}

				System.out.println("Updated Deatils : " + acc);

				flag = true;

			}

		}
		if (!flag) {
			System.out.println("Account Does't Exist");
		}

	}
	
	public void updateName() {

		System.out.println("Update Your Name : ");
		for (Account acc : a) {
			if (acc != null) {
				acc.setAccName(Validation.holderName());
			}

		}

		System.out.println();
	}

	public void updateContact() {

		System.out.println("Update Your Contact No. :");

		for (Account acc : a) {
			if (acc != null) {
				acc.setContact(sc.nextLong());
			}
		}
		System.out.println();
	}

	public void updateEmail() {

		System.out.println("Update Your Email Id");

		for (Account acc : a) {
			if (acc != null) {
				acc.setEmail(sc.next());
			}
		}
		System.out.println();
	}
	
	


}
