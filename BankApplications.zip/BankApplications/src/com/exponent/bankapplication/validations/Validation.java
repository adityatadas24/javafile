package com.exponent.bankapplication.validations;

import java.util.Scanner;
import java.util.regex.Pattern;

import com.exponent.bankapplication.serviceImp.SBI;

public class Validation {
	static Scanner sc = new Scanner(System.in);

	public static String holderName() {

//			System.out.println("Enter Your Name : ");

		String name = sc.next();

		if (Pattern.matches("[a-zA-Z]+", name)) {
			return name;

		} else {
			System.out.println("Invalid input");
			return holderName();
		}

	}

	public static String adharCardNo() {
		System.out.println("Enter AdharCard Number : ");
		String aadharCard = sc.next();

//		long number = Long.valueOf(adharCard);

//		if(adharCard.length() == 12) {
//			return adharCard;
//		}else {
//			System.out.println("AdharCard no. should be 12 digit");
//			return adharCardNo();
//		}

		if (Pattern.matches("[0-9]{12}", aadharCard)) {
			return aadharCard;
		} else if (Pattern.matches("[a-zA-Z]+", aadharCard)) {
			System.out.println("AadharCard input should be in number");
			return adharCardNo();
		} else {
			System.out.println("AadharCard no. should be 12 digit");
			return adharCardNo();
		}

	}

	public static String pancard() {
		System.out.println("Enter Your PanCard");
		String pan = sc.next();

		String upperPan = pan.toUpperCase();

		if (Pattern.matches("[A-Z]{5}[0-9]{4}[A-Z]{1}", upperPan)) {
			return upperPan;
		} else {
			System.out.println("Pancard input should be in 10 characters");
			return pancard();
		}

	}

	public static long contactNo() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Your Contact No. :");
		String contact;

		try {
			contact = sc.next();
			long con = Long.valueOf(contact);
			if (Pattern.matches("^\\+?91?[0-9]{10}$", contact)) {
				return Long.valueOf(contact.replace("+91", ""));
			} else {
				System.out.println("Invalid Contact Number! Please enter a 10-digit number.");
				return contactNo();
			}

		} catch (Exception e) {
			System.out.println("Invalid Input! Contact should be in Number");
			return contactNo();
		}

	}

	public static String emailId() {
		System.out.println("Enter Your Email Id");
		String email = sc.next();

		if (Pattern.matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}$", email)) {
			return email;
		} else {
			System.out.println("Email is not valid");
			return emailId();
		}

	}

	public static double accBalance() {
		System.out.println("Enter Account Opening Balance : ");

		double balance;

		try {

			balance = sc.nextDouble();

			if (balance > 1000) {
				return balance;
			} else {
				System.out.println("The Opening Balance should be Greater than 1000");
				return accBalance();
			}
		} catch (Exception e) {
			System.out.println("Invalid Input it must be in number");
			return accBalance();
		}

	}
	

	public static int createsAccountsNo() {
		Scanner sc = new Scanner(System.in);

		int n;

		try {
			n = sc.nextInt();
		} catch (Exception e) {
			System.out.println("Invalid Input it must be in number");
			return createsAccountsNo();
		}

		return n;

	}
	
	public static int passwords() {
		Scanner sc = new Scanner(System.in);
		int password = 1234;
		System.out.println("Enter Your Password");
		int pass = sc.nextInt();
		
		if(password == pass) {
			 return password;
		}else {
			System.out.println("Invalid Password");
			return passwords();
		}
	
		
	}

}
